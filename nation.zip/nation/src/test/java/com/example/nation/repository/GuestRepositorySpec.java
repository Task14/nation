package com.example.nation.repository;

import com.example.nation.models.entities.Guest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GuestRepositorySpec {
    
    @Autowired
    private GuestRepository guestRepository;
    
    @Before
    public void setUp() throws Exception {
        Guest guest1= new Guest();
        Guest guest2= new Guest();
        //save Country, verify has ID value after save
        assertNull(guest1.getGuest_id());
        assertNull(guest2.getGuest_id());//null before save
        this.guestRepository.save(guest1);
        this.guestRepository.save(guest2);
        assertNotNull(guest1.getGuest_id());
        assertNotNull(guest2.getGuest_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        Guest guestA = guestRepository.findByName("Bob");
        assertNotNull(guestA);
        assertEquals("Bob", guestA.getName());
        /*Get all products, list should only have two*/
        Iterable<Guest> Countrys = guestRepository.findAll();
        int count = 0;
        for(Guest p : Countrys){
            count++;
        }
        assertEquals(count, 2);
    }
}