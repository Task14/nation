package com.example.nation.repository;

import com.example.nation.models.entities.Country;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CountryRepositorySpec {
    
    @Autowired
    private CountryRepository countryRepository;
    
    @Before
    public void setUp() throws Exception {
        Country Country1= new Country();
        Country Country2= new Country();
        //save Country, verify has ID value after save
        assertNull(Country1.getCountry_id());
        assertNull(Country2.getCountry_id());//null before save
        this.countryRepository.save(Country1);
        this.countryRepository.save(Country2);
        assertNotNull(Country1.getCountry_id());
        assertNotNull(Country2.getCountry_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        Country CountryA = countryRepository.findByName("Greece");
        assertNotNull(CountryA);
        assertEquals("Greece", CountryA.getName());
        /*Get all products, list should only have two*/
        Iterable<Country> countries = countryRepository.findAll();
        int count = 0;
        for(Country p : countries){
            count++;
        }
        assertEquals(count, 2);
    }
}