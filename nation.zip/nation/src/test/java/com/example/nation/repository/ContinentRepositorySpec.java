package com.example.nation.repository;

import com.example.nation.models.entities.Continent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ContinentRepositorySpec {
    
    @Autowired
    private ContinentRepository continentRepository;
    
    @Before
    public void setUp() throws Exception {
        Continent continent1= new Continent();
        Continent continent2= new Continent();
        //save Country, verify has ID value after save
        assertNull(continent1.getContinent_id());
        assertNull(continent2.getContinent_id());//null before save
        this.continentRepository.save(continent1);
        this.continentRepository.save(continent2);
        assertNotNull(continent1.getContinent_id());
        assertNotNull(continent2.getContinent_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        Continent continentA = continentRepository.findByName("ContinentA");
        assertNotNull(continentA);
        assertEquals("ContinentA", continentA.getName());
        /*Get all products, list should only have two*/
        Iterable<Continent> continents = continentRepository.findAll();
        int count = 0;
        for(Continent p : continents){
            count++;
        }
        assertEquals(count, 2);
    }
}