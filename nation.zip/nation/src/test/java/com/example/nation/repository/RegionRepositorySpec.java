package com.example.nation.repository;

import com.example.nation.models.entities.Region;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RegionRepositorySpec {
    
    @Autowired
    private RegionRepository regionRepository;
    
    @Before
    public void setUp() throws Exception {
        Region region1= new Region();
        Region region2= new Region();
        //save Country, verify has ID value after save
        assertNull(region1.getRegion_id());
        assertNull(region2.getRegion_id());//null before save
        this.regionRepository.save(region1);
        this.regionRepository.save(region2);
        assertNotNull(region1.getRegion_id());
        assertNotNull(region2.getRegion_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        Region regionA = regionRepository.findByName("RegionA");
        assertNotNull(regionA);
        assertEquals("RegionA", regionA.getName());
        /*Get all products, list should only have two*/
        Iterable<Region> regions = regionRepository.findAll();
        int count = 0;
        for(Region p : regions){
            count++;
        }
        assertEquals(count, 2);
    }
}