package com.example.nation.repository;

import com.example.nation.models.entities.CountryLanguage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CountryLanguageRepositorySpec {
    
    @Autowired
    private CountryLanguageRepository countryLanguageRepository;
    
    @Before
    public void setUp() throws Exception {
        CountryLanguage countryLanguage1= new CountryLanguage();
        CountryLanguage countryLanguage2= new CountryLanguage();
        //save Country, verify has ID value after save
        assertNull(countryLanguage1.getCountry_id());
        assertNull(countryLanguage2.getCountry_id());//null before save
        this.countryLanguageRepository.save(countryLanguage1);
        this.countryLanguageRepository.save(countryLanguage2);
        assertNotNull(countryLanguage1.getCountry_id());
        assertNotNull(countryLanguage2.getCountry_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        CountryLanguage countryLanguageA = countryLanguageRepository.findByName("Greek");
        assertNotNull(countryLanguageA);
        assertEquals(Optional.of(1), countryLanguageA.getLanguage_id());
        /*Get all products, list should only have two*/
        Iterable<CountryLanguage> countryLanguages = countryLanguageRepository.findAll();
        int count = 0;
        for(CountryLanguage p : countryLanguages){
            count++;
        }
        assertEquals(count, 2);
    }
}