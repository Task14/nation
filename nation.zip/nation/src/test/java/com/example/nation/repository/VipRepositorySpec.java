package com.example.nation.repository;

import com.example.nation.models.entities.Vip;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class VipRepositorySpec {
    
    @Autowired
    private VipRepository vipRepository;
    
    @Before
    public void setUp() throws Exception {
        Vip Vip1= new Vip();
        Vip Vip2= new Vip();
        //save Vip, verify has ID value after save
        assertNull(Vip1.getVip_id());
        assertNull(Vip2.getVip_id());//null before save
        this.vipRepository.save(Vip1);
        this.vipRepository.save(Vip2);
        assertNotNull(Vip1.getVip_id());
        assertNotNull(Vip2.getVip_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        Vip VipA = vipRepository.findByName("Bob");
        assertNotNull(VipA);
        assertEquals("Bob", VipA.getName());
        /*Get all products, list should only have two*/
        Iterable<Vip> Vips = vipRepository.findAll();
        int count = 0;
        for(Vip p : Vips){
            count++;
        }
        assertEquals(count, 2);
    }
}