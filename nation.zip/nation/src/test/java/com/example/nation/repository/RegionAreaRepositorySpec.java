package com.example.nation.repository;

import com.example.nation.models.entities.RegionArea;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RegionAreaRepositorySpec {
    
    @Autowired
    private RegionAreaRepository regionAreaRepository;
    
    @Before
    public void setUp() throws Exception {
        RegionArea regionArea1= new RegionArea();
        RegionArea regionArea2= new RegionArea();
        //save Country, verify has ID value after save
        assertNull(regionArea1.getRegion_name());
        assertNull(regionArea2.getRegion_name());//null before save
        this.regionAreaRepository.save(regionArea1);
        this.regionAreaRepository.save(regionArea2);
        assertNotNull(regionArea1.getRegion_name());
        assertNotNull(regionArea2.getRegion_name());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        RegionArea regionAreaA = regionAreaRepository.findByName("AreaA");
        assertNotNull(regionAreaA);
        assertEquals("AreaA", regionAreaA.getRegion_name());
        /*Get all products, list should only have two*/
        Iterable<RegionArea> regionAreas = regionAreaRepository.findAll();
        int count = 0;
        for(RegionArea p : regionAreas){
            count++;
        }
        assertEquals(count, 2);
    }
}