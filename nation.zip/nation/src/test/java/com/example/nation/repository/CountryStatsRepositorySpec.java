package com.example.nation.repository;

import com.example.nation.models.entities.CountryStats;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CountryStatsRepositorySpec {
    
    @Autowired
    private CountryStatsRepository countryStatsRepository;
    
    @Before
    public void setUp() throws Exception {
        CountryStats countryStats1= new CountryStats(1, 2020, 5, 1.0);
        CountryStats countryStats2= new CountryStats();
        //save Country, verify has ID value after save
        assertNull(countryStats1.getCountry_id());
        assertNull(countryStats2.getCountry_id());//null before save
        this.countryStatsRepository.save(countryStats1);
        this.countryStatsRepository.save(countryStats2);
        assertNotNull(countryStats1.getCountry_id());
        assertNotNull(countryStats2.getCountry_id());
    }
    @Test
    public void testFetchData(){
        /*Test data retrieval*/
        CountryStats countryStatsA = countryStatsRepository.findByName("");
        assertNotNull(countryStatsA);
        assertEquals(Optional.of(5), countryStatsA.getPopulation());
        /*Get all products, list should only have two*/
        Iterable<CountryStats> countryStats = countryStatsRepository.findAll();
        int count = 0;
        for(CountryStats p : countryStats){
            count++;
        }
        assertEquals(count, 2);
    }
}