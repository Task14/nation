package com.example.nation.models.entities;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "region")
public class Region {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer region_id;
    private String name;
    private int continent_id;

   @Override
    public String toString() {
        return "Region{" +
                ", name='" + name + '\'' +
                ", continent_id=" + continent_id +
                '}';
    }
}