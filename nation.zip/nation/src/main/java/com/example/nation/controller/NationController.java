package com.example.nation.controller;

import com.example.nation.handler.NationHandler;
import com.example.nation.models.dto.response.CountriesResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NationController {

    @Autowired
    private NationHandler nationHandler;

    @GetMapping(value = "/countries")
    public CountriesResponseDto getAllCountries() {
        return nationHandler.handle();
    }
}
