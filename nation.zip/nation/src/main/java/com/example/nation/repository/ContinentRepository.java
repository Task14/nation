package com.example.nation.repository;

import com.example.nation.models.entities.Continent;
import org.springframework.data.repository.CrudRepository;

public interface ContinentRepository extends CrudRepository<Continent, Integer> {
    Continent findByName(String name);
}