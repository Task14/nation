package com.example.nation.repository;

import com.example.nation.models.entities.Guest;
import org.springframework.data.repository.CrudRepository;

public interface GuestRepository extends CrudRepository<Guest, Integer> {
    Guest findByName(String name);
}