package com.example.nation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NationApplication {

	public static void main(String[] args) {
		SpringApplication.run(NationApplication.class, args);
	}


}
