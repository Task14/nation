package com.example.nation.models.entities;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "region_area")
public class RegionArea {
    @Id
    private String region_name;
    private double region_area;

    @Override
    public String toString() {
        return "RegionArea{" +
                ", region_name='" + region_name + '\'' +
                ", region_area=" + region_area +
                '}';
    }
}