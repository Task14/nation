package com.example.nation.models.entities;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "countries")
public class Country {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer country_id;
    private String name;
    private double area;
    private Date national_day;
    private String country_code2;
    private String country_code3;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "region_id", referencedColumnName = "region_id")
    private Region region_id;

    @Override
    public String toString() {
        return "Country{" +
                ", name='" + name + '\'' +
                ", area=" + area + '\'' +
                ", national_day=" + national_day + '\'' +
                ", country_code2=" + country_code2 + '\'' +
                ", country_code3=" + country_code3 + '\'' +
                ", region_id=" + region_id +
                '}';
    }
}