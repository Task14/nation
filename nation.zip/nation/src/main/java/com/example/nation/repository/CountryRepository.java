package com.example.nation.repository;

import com.example.nation.models.entities.Country;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CountryRepository extends CrudRepository<Country, Integer> {

    Country findByName(String name);

}