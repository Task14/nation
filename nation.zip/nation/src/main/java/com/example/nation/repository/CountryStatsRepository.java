package com.example.nation.repository;

import com.example.nation.models.entities.CountryStats;
import org.springframework.data.repository.CrudRepository;

public interface CountryStatsRepository extends CrudRepository<CountryStats, Integer> {
    CountryStats findByName(String name);
}