package com.example.nation.repository;

import com.example.nation.models.entities.RegionArea;
import org.springframework.data.repository.CrudRepository;

public interface RegionAreaRepository extends CrudRepository<RegionArea, Integer> {
    RegionArea findByName(String name);
}