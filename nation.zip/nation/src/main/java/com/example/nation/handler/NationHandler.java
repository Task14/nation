package com.example.nation.handler;

import com.example.nation.models.dto.response.CountriesResponseDto;
import com.example.nation.service.NationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration
public class NationHandler {

    @Autowired
    private NationService nationService;


    public CountriesResponseDto handle() {
        return nationService.getCountries();
    }
}
