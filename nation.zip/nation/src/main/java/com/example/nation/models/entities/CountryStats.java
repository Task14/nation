package com.example.nation.models.entities;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "country_stats")
public class CountryStats {

    private Integer country_id;
    @Id
    private Integer year;
    private Integer population;
    private double gdp;

    @Override
    public String toString() {
        return "CountryStats{" +
                ", country_id='" + country_id + '\'' +
                ", population='" + population + '\'' +
                ", gdp='" + gdp + '\'' +
                ", year=" + year +
                '}';
    }
}