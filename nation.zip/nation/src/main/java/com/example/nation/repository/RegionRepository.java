package com.example.nation.repository;

import com.example.nation.models.entities.Region;
import org.springframework.data.repository.CrudRepository;

public interface RegionRepository extends CrudRepository<Region, Integer> {
    Region findByName(String name);
}