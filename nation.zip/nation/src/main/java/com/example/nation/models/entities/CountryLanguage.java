package com.example.nation.models.entities;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "country_languages")
public class CountryLanguage {

    private Integer country_id;
    private Integer language_id;
    private short official;

    @Override
    public String toString() {
        return "CountryLanguage{" +
                ", country_id='" + country_id + '\'' +
                ", language_id='" + language_id + '\'' +
                ", official=" + official +
                '}';
    }
}