package com.example.nation.service;

import com.example.nation.models.dto.response.CountriesResponseDto;
import com.example.nation.models.dto.response.dto.CountryDto;
import com.example.nation.repository.CountryRepository;
import com.example.nation.models.entities.Country;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NationService {

    @Autowired
    private CountryRepository countryRepository;

    public CountriesResponseDto getCountries() {
        List<Country> countries = (List<Country>) countryRepository.findAll();
        return CountriesResponseDto.builder().countries(countries
                .stream()
                .map(this::countryToDto)
                .collect(Collectors.toList()))
                .build();
    }

    private CountryDto countryToDto(Country country) {
        return CountryDto.builder()
                .name(country.getName()).build();
    }
}
